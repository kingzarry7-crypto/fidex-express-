
import base64
import hashlib
import hmac
import json
import os
import secrets
import smtplib
import time
from datetime import datetime, timezone
from email.message import EmailMessage
from typing import Optional

from fastapi import Cookie, FastAPI, Header, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, EmailStr, Field

from database import (
    add_event,
    create_package,
    get_package,
    init_db,
    list_packages,
    update_package,
)

app = FastAPI(title="Fidex Express Tracking API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["Content-Type", "X-CSRF-Token"],
)

ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "Fedexg217@gmail.com").strip().lower()
SESSION_SECRET = os.getenv("SESSION_SECRET", "").strip()
COOKIE_NAME = "fidex_admin_session"
SESSION_TTL = 60 * 60 * 8
STATUSES = [
    "Registered",
    "Pickup Scheduled",
    "Picked Up",
    "In Transit",
    "At Destination Facility",
    "Customs Clearance",
    "Out for Delivery",
    "Delivered",
    "Exception",
    "Cancelled",
]


class AdminLogin(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=256)


class PackageCreate(BaseModel):
    recipient_name: str = Field(min_length=1, max_length=160)
    recipient_email: Optional[EmailStr] = None
    recipient_phone: Optional[str] = Field(default=None, max_length=40)
    sender_name: Optional[str] = Field(default=None, max_length=160)
    sender_email: Optional[EmailStr] = None
    sender_phone: Optional[str] = Field(default=None, max_length=40)
    origin: str = Field(min_length=1, max_length=160)
    destination: str = Field(min_length=1, max_length=160)
    description: Optional[str] = Field(default=None, max_length=500)
    weight_kg: Optional[float] = Field(default=None, ge=0, le=100000)
    service: str = Field(default="Express", min_length=1, max_length=80)
    shipping_cost: Optional[float] = Field(default=None, ge=0)
    currency: str = Field(default="GBP", min_length=3, max_length=3)
    estimated_delivery: Optional[str] = Field(default=None, max_length=40)
    current_location: str = Field(default="Origin Facility", min_length=1, max_length=160)
    status: str = Field(default="Registered", min_length=1, max_length=80)


class StatusUpdate(BaseModel):
    status: str = Field(min_length=1, max_length=80)
    location: str = Field(min_length=1, max_length=160)
    message: Optional[str] = Field(default=None, max_length=500)


def _password_ok(password: str) -> bool:
    expected = os.getenv("ADMIN_PASSWORD", "")
    if not expected:
        return False
    return hmac.compare_digest(password, expected)


def _sign(payload: str) -> str:
    if not SESSION_SECRET:
        raise RuntimeError("SESSION_SECRET is not configured")
    return hmac.new(
        SESSION_SECRET.encode(), payload.encode(), hashlib.sha256
    ).hexdigest()


def _make_session(email: str) -> tuple[str, str]:
    csrf = secrets.token_urlsafe(24)
    payload = {
        "email": email.lower(),
        "exp": int(time.time()) + SESSION_TTL,
        "csrf": csrf,
    }
    raw = base64.urlsafe_b64encode(
        json.dumps(payload, separators=(",", ":")).encode()
    ).decode()
    return f"{raw}.{_sign(raw)}", csrf


def _read_session(cookie: Optional[str]) -> dict:
    if not cookie or "." not in cookie:
        raise HTTPException(status_code=401, detail="Admin login required")
    raw, signature = cookie.rsplit(".", 1)
    try:
        if not hmac.compare_digest(_sign(raw), signature):
            raise ValueError("bad signature")
        data = json.loads(base64.urlsafe_b64decode(raw.encode()).decode())
        if data.get("email", "").lower() != ADMIN_EMAIL:
            raise ValueError("wrong admin")
        if int(data.get("exp", 0)) < int(time.time()):
            raise ValueError("expired")
        return data
    except Exception:
        raise HTTPException(status_code=401, detail="Admin session expired")


def _require_admin(
    cookie: Optional[str],
    csrf_header: Optional[str] = None,
) -> dict:
    data = _read_session(cookie)
    if csrf_header is not None and not hmac.compare_digest(
        csrf_header, str(data.get("csrf", ""))
    ):
        raise HTTPException(status_code=403, detail="Invalid CSRF token")
    return data


def _generate_tracking_number() -> str:
    # FID = Fidex Express, avoiding a FedEx-branded tracking prefix.
    return "FID" + "".join(str(secrets.randbelow(10)) for _ in range(10))


def _send_email(to_email: Optional[str], subject: str, body: str) -> bool:
    if not to_email:
        return False
    smtp_user = os.getenv("SMTP_USER", "").strip()
    smtp_password = os.getenv("SMTP_PASSWORD", "").strip()
    smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com").strip()
    smtp_port = int(os.getenv("SMTP_PORT", "587"))
    from_email = os.getenv("FROM_EMAIL", smtp_user or ADMIN_EMAIL).strip()
    if not smtp_user or not smtp_password:
        return False

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = from_email
    msg["To"] = to_email
    msg.set_content(body)

    try:
        with smtplib.SMTP(smtp_host, smtp_port, timeout=15) as smtp:
            smtp.starttls()
            smtp.login(smtp_user, smtp_password)
            smtp.send_message(msg)
        return True
    except Exception:
        return False


def _package_email(pkg: dict, event_message: str) -> str:
    return f"""Hello {pkg["recipient_name"]},

Your Fidex Express shipment has an update.

Tracking number: {pkg["tracking_number"]}
Status: {pkg["status"]}
Location: {pkg["current_location"]}
Update: {event_message}

Track your shipment on the Fidex Express website using your tracking number.

Fidex Express
{ADMIN_EMAIL}
"""


@app.on_event("startup")
def startup() -> None:
    init_db()


@app.get("/")
def home():
    return {"status": "Fidex Express API is running", "version": "2.0.0"}


@app.get("/api/health")
def health():
    return {"ok": True, "database": "configured"}


@app.get("/api/track/{tracking_num}")
def track_package(tracking_num: str):
    pkg = get_package(tracking_num.strip().upper())
    if not pkg:
        raise HTTPException(status_code=404, detail="Tracking number not found")
    return pkg


@app.post("/api/admin/login")
def admin_login(credentials: AdminLogin, response: Response):
    if not SESSION_SECRET:
        raise HTTPException(status_code=503, detail="SESSION_SECRET is not configured")
    if credentials.email.lower().strip() != ADMIN_EMAIL:
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    if not _password_ok(credentials.password):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")

    session, csrf = _make_session(ADMIN_EMAIL)
    response.set_cookie(
        COOKIE_NAME,
        session,
        httponly=True,
        secure=(os.getenv("COOKIE_SECURE", "true").lower() == "true"),
        samesite="lax",
        max_age=SESSION_TTL,
        path="/",
    )
    return {"ok": True, "csrf_token": csrf, "admin_email": ADMIN_EMAIL}


@app.post("/api/admin/logout")
def admin_logout(response: Response):
    response.delete_cookie(COOKIE_NAME, path="/")
    return {"ok": True}


@app.get("/api/admin/session")
def admin_session(cookie: Optional[str] = Cookie(default=None, alias=COOKIE_NAME)):
    data = _require_admin(cookie)
    return {"ok": True, "admin_email": data["email"], "csrf_token": data["csrf"]}


@app.get("/api/admin/packages")
def admin_packages(
    cookie: Optional[str] = Cookie(default=None, alias=COOKIE_NAME),
):
    _require_admin(cookie)
    return {"packages": list_packages()}


@app.post("/api/admin/packages")
def admin_create_package(
    pkg: PackageCreate,
    cookie: Optional[str] = Cookie(default=None, alias=COOKIE_NAME),
    csrf_header: Optional[str] = Header(default=None, alias="X-CSRF-Token"),
):
    _require_admin(cookie, csrf_header)
    if pkg.status not in STATUSES:
        raise HTTPException(status_code=400, detail="Invalid package status")

    tracking_number = _generate_tracking_number()
    for _ in range(5):
        if not get_package(tracking_number):
            break
        tracking_number = _generate_tracking_number()

    created = create_package(
        tracking_number=tracking_number,
        recipient_name=pkg.recipient_name,
        recipient_email=str(pkg.recipient_email) if pkg.recipient_email else None,
        recipient_phone=pkg.recipient_phone,
        sender_name=pkg.sender_name,
        sender_email=str(pkg.sender_email) if pkg.sender_email else None,
        sender_phone=pkg.sender_phone,
        origin=pkg.origin,
        destination=pkg.destination,
        description=pkg.description,
        weight_kg=pkg.weight_kg,
        service=pkg.service,
        shipping_cost=pkg.shipping_cost,
        currency=pkg.currency.upper(),
        estimated_delivery=pkg.estimated_delivery,
        current_location=pkg.current_location,
        status=pkg.status,
    )

    message = "Shipment registered in the Fidex Express system."
    add_event(tracking_number, pkg.status, pkg.current_location, message)
    created = get_package(tracking_number)
    email_sent = _send_email(
        created.get("recipient_email"),
        f"Fidex Express shipment registered: {tracking_number}",
        _package_email(created, message),
    )
    return {"ok": True, "package": created, "email_sent": email_sent}


@app.patch("/api/admin/packages/{tracking_num}")
def admin_update_package(
    tracking_num: str,
    update: StatusUpdate,
    cookie: Optional[str] = Cookie(default=None, alias=COOKIE_NAME),
    csrf_header: Optional[str] = Header(default=None, alias="X-CSRF-Token"),
):
    _require_admin(cookie, csrf_header)
    if update.status not in STATUSES:
        raise HTTPException(status_code=400, detail="Invalid package status")
    tracking_number = tracking_num.strip().upper()
    if not get_package(tracking_number):
        raise HTTPException(status_code=404, detail="Package not found")

    update_package(tracking_number, update.status, update.location)
    message = update.message or f"Shipment status changed to {update.status}."
    add_event(tracking_number, update.status, update.location, message)

    pkg = get_package(tracking_number)
    email_sent = _send_email(
        pkg.get("recipient_email"),
        f"Fidex Express tracking update: {tracking_number}",
        _package_email(pkg, message),
    )
    return {"ok": True, "package": pkg, "email_sent": email_sent}


@app.get("/api/admin/statuses")
def statuses():
    return {"statuses": STATUSES}
