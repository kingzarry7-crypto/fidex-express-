
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any

DATABASE_URL = os.getenv("DATABASE_URL", "").strip()


def _now():
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def _db():
    if DATABASE_URL:
        import psycopg
        from psycopg.rows import dict_row

        conn = psycopg.connect(DATABASE_URL, row_factory=dict_row)
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    else:
        conn = sqlite3.connect("packages.db")
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def init_db():
    if DATABASE_URL:
        with _db() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS packages (
                    tracking_number TEXT PRIMARY KEY,
                    recipient_name TEXT NOT NULL,
                    recipient_email TEXT,
                    recipient_phone TEXT,
                    sender_name TEXT,
                    sender_email TEXT,
                    sender_phone TEXT,
                    origin TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    description TEXT,
                    weight_kg DOUBLE PRECISION,
                    service TEXT NOT NULL,
                    shipping_cost DOUBLE PRECISION,
                    currency VARCHAR(3) NOT NULL DEFAULT 'GBP',
                    estimated_delivery TEXT,
                    status TEXT NOT NULL,
                    current_location TEXT NOT NULL,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tracking_events (
                    id BIGSERIAL PRIMARY KEY,
                    tracking_number TEXT NOT NULL REFERENCES packages(tracking_number) ON DELETE CASCADE,
                    status TEXT NOT NULL,
                    location TEXT NOT NULL,
                    message TEXT,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)
    else:
        with _db() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS packages (
                    tracking_number TEXT PRIMARY KEY,
                    recipient_name TEXT NOT NULL,
                    recipient_email TEXT,
                    recipient_phone TEXT,
                    sender_name TEXT,
                    sender_email TEXT,
                    sender_phone TEXT,
                    origin TEXT NOT NULL,
                    destination TEXT NOT NULL,
                    description TEXT,
                    weight_kg REAL,
                    service TEXT NOT NULL,
                    shipping_cost REAL,
                    currency TEXT NOT NULL DEFAULT 'GBP',
                    estimated_delivery TEXT,
                    status TEXT NOT NULL,
                    current_location TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS tracking_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tracking_number TEXT NOT NULL,
                    status TEXT NOT NULL,
                    location TEXT NOT NULL,
                    message TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(tracking_number) REFERENCES packages(tracking_number) ON DELETE CASCADE
                )
            """)


def _rows_to_dict(rows):
    return [dict(row) for row in rows]


def create_package(**data):
    now = _now()
    with _db() as conn:
        conn.execute(
            """
            INSERT INTO packages (
                tracking_number, recipient_name, recipient_email, recipient_phone,
                sender_name, sender_email, sender_phone, origin, destination,
                description, weight_kg, service, shipping_cost, currency,
                estimated_delivery, status, current_location, created_at, updated_at
            ) VALUES (
                %(tracking_number)s, %(recipient_name)s, %(recipient_email)s, %(recipient_phone)s,
                %(sender_name)s, %(sender_email)s, %(sender_phone)s, %(origin)s, %(destination)s,
                %(description)s, %(weight_kg)s, %(service)s, %(shipping_cost)s, %(currency)s,
                %(estimated_delivery)s, %(status)s, %(current_location)s, %(created_at)s, %(updated_at)s
            )
            """ if DATABASE_URL else """
            INSERT INTO packages (
                tracking_number, recipient_name, recipient_email, recipient_phone,
                sender_name, sender_email, sender_phone, origin, destination,
                description, weight_kg, service, shipping_cost, currency,
                estimated_delivery, status, current_location, created_at, updated_at
            ) VALUES (
                :tracking_number, :recipient_name, :recipient_email, :recipient_phone,
                :sender_name, :sender_email, :sender_phone, :origin, :destination,
                :description, :weight_kg, :service, :shipping_cost, :currency,
                :estimated_delivery, :status, :current_location, :created_at, :updated_at
            )
            """,
            {**data, "created_at": now, "updated_at": now},
        )
    return get_package(data["tracking_number"])


def get_package(tracking_number):
    with _db() as conn:
        if DATABASE_URL:
            row = conn.execute(
                "SELECT * FROM packages WHERE tracking_number = %s",
                (tracking_number,),
            ).fetchone()
            if not row:
                return None
            events = conn.execute(
                """SELECT id, status, location, message, created_at
                   FROM tracking_events
                   WHERE tracking_number = %s
                   ORDER BY created_at DESC, id DESC""",
                (tracking_number,),
            ).fetchall()
        else:
            row = conn.execute(
                "SELECT * FROM packages WHERE tracking_number = ?",
                (tracking_number,),
            ).fetchone()
            if not row:
                return None
            events = conn.execute(
                """SELECT id, status, location, message, created_at
                   FROM tracking_events
                   WHERE tracking_number = ?
                   ORDER BY created_at DESC, id DESC""",
                (tracking_number,),
            ).fetchall()

        result = dict(row)
        result["events"] = _rows_to_dict(events)
        return result


def list_packages():
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM packages ORDER BY updated_at DESC"
        ).fetchall()
        packages = []
        for row in rows:
            pkg = dict(row)
            if DATABASE_URL:
                events = conn.execute(
                    """SELECT id, status, location, message, created_at
                       FROM tracking_events WHERE tracking_number = %s
                       ORDER BY created_at DESC, id DESC""",
                    (pkg["tracking_number"],),
                ).fetchall()
            else:
                events = conn.execute(
                    """SELECT id, status, location, message, created_at
                       FROM tracking_events WHERE tracking_number = ?
                       ORDER BY created_at DESC, id DESC""",
                    (pkg["tracking_number"],),
                ).fetchall()
            pkg["events"] = _rows_to_dict(events)
            packages.append(pkg)
        return packages


def update_package(tracking_number, status, location):
    now = _now()
    with _db() as conn:
        if DATABASE_URL:
            conn.execute(
                """UPDATE packages
                   SET status = %s, current_location = %s, updated_at = NOW()
                   WHERE tracking_number = %s""",
                (status, location, tracking_number),
            )
        else:
            conn.execute(
                """UPDATE packages
                   SET status = ?, current_location = ?, updated_at = ?
                   WHERE tracking_number = ?""",
                (status, location, now, tracking_number),
            )


def add_event(tracking_number, status, location, message=None):
    now = _now()
    with _db() as conn:
        if DATABASE_URL:
            conn.execute(
                """INSERT INTO tracking_events
                   (tracking_number, status, location, message, created_at)
                   VALUES (%s, %s, %s, %s, NOW())""",
                (tracking_number, status, location, message),
            )
        else:
            conn.execute(
                """INSERT INTO tracking_events
                   (tracking_number, status, location, message, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                (tracking_number, status, location, message, now),
            )
