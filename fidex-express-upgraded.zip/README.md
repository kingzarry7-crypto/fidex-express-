# Fidex Express 2.0

Admin-only package registration and public tracking for Vercel + FastAPI.

## What changed

- Public tracking uses the real API/database, not simulated results.
- Admin login at `/admin.html`.
- Only the configured admin can register packages.
- Unique `FID##########` tracking numbers are generated server-side.
- Package details and tracking history are stored.
- Admin can update status/location and add a customer-facing message.
- Optional email notifications use SMTP (Gmail works with a Google App Password).
- PostgreSQL is recommended for Vercel production; SQLite remains available for local development.

## Files

- `index.html` public tracking site
- `admin.html` admin dashboard
- `main.py` FastAPI application
- `database.py` PostgreSQL/SQLite data layer
- `api/index.py` Vercel FastAPI entrypoint
- `requirements.txt` Python dependencies

## Vercel environment variables

Required:

`ADMIN_EMAIL=Fedexg217@gmail.com`

`ADMIN_PASSWORD=<strong admin password>`

`SESSION_SECRET=<long random secret>`

Production database:

`DATABASE_URL=<Neon PostgreSQL connection string>`

Email notifications:

`SMTP_HOST=smtp.gmail.com`

`SMTP_PORT=587`

`SMTP_USER=Fedexg217@gmail.com`

`SMTP_PASSWORD=<Google App Password>`

`FROM_EMAIL=Fedexg217@gmail.com`

## Deploy

1. Connect the GitHub repo to Vercel.
2. Add the environment variables above under Project Settings → Environment Variables.
3. Add a Neon PostgreSQL database and copy its connection string to `DATABASE_URL`.
4. Push the files to `main`.
5. Vercel redeploys automatically.
6. Open `/admin.html`.
7. Sign in with `ADMIN_EMAIL` and `ADMIN_PASSWORD`.
8. Register a package. The system generates a tracking number.
9. Give the tracking number to the recipient.
10. The recipient uses the public homepage to track it.

## Gmail

Do not put your normal Gmail password in GitHub. Use a Google App Password as `SMTP_PASSWORD`, with 2-Step Verification enabled on the Google account.

## Important

This project is for an independently operated logistics service. Do not represent it as FedEx or another third party without authorization.
